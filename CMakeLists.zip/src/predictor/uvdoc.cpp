//
// Created by h30073568 on 25-7-21.
//
#include "./BasePredictor.cpp"

class UvDocPredictor : BasePredictor {
public:
    UvDocPredictor(): BasePredictor("UVDoc_infer") {
    }
};
