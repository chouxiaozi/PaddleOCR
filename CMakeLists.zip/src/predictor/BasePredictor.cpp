//
// Created by h30073568 on 25-7-21.
//
#include "paddle_inference_api.h"
#include <string>
#include <thread>
#include <windows.h>

using namespace paddle_infer;
using namespace paddle;
using namespace std;

static const string &BASE_MODEL_DIR = "D:/data/clionWs/paddleJni/models/";


class BasePredictor {
protected:
    Config config;
    shared_ptr<Predictor> predictor_;

public:
    BasePredictor(const string &modelName) {
        SYSTEM_INFO sysInfo;

        GetSystemInfo(&sysInfo);

        config.SetModel(BASE_MODEL_DIR + modelName + "/inference.json",
                        BASE_MODEL_DIR + modelName + "/inference.pdiparams");
        config.SetCpuMathLibraryNumThreads(sysInfo.dwNumberOfProcessors);
        config.DisableGlogInfo();
        // config.EnableMemoryOptim();


        std::cout << "bbbb:" + config.Summary() << std::endl;
        this->predictor_ = CreatePredictor(config);
    }


    auto run() {
    }
};
