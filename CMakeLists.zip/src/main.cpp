#include <iostream>
#include "paddle_inference_api.h"
#include "./predictor/uvdoc.cpp"
using namespace paddle_infer;


int main() {
    UvDocPredictor predictor;
    std::cout << "Hello, World!" << std::endl;

    return 0;
}
