#include <iostream>
#include "paddle_inference_api.h"

using namespace paddle_infer;

int main() {

    // 字符串 prog_file 为 Combine 模型文件所在路径
    std::string prog_file = "../assets/models/mobilenet_v1.pdmodel";
    // 字符串 params_file 为 Combine 模型参数文件所在路径
    std::string params_file = "../assets/models/mobilenet_v1.pdiparams";

    Config config;
    config.DisableGpu();
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
